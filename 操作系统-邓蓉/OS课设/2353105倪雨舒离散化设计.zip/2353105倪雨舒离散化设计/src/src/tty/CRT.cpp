#include "CRT.h"
#include "IOPort.h"

// 显存指针与光标位罄1�71ￄ1�77
unsigned short* CRT::m_VideoMemory = (unsigned short*)(0xB8000 + 0xC0000000);
unsigned int CRT::m_CursorX = 0;
unsigned int CRT::m_CursorY = 0;
char* CRT::m_Position = 0;
char* CRT::m_BeginChar = 0;

// 屏幕行数
unsigned int CRT::ROWS = 15;

// ======= 滚动缓冲区相关静态成员定乄1�71ￄ1�77 =======
unsigned short* CRT::m_ScrollBuffer = 0;
unsigned int    CRT::m_CurrentLine = 0;
unsigned int    CRT::m_TotalLinesWritten = 0;
unsigned int    CRT::m_ScrollOffset = 0;
bool            CRT::m_IsScrolling = false;

//======================================================================
// 仄1�71ￄ1�77 TTY 输出队列取字符并显示
//======================================================================
void CRT::CRTStart(TTy* pTTy)
{
    char ch;
    if (0 == CRT::m_BeginChar)
    {
        m_BeginChar = pTTy->t_outq.CurrentChar();
    }
    if (0 == m_Position)
    {
        m_Position = m_BeginChar;
    }

    while ((ch = pTTy->t_outq.GetChar()) != TTy::GET_ERROR)
    {
        switch (ch)
        {
        case '\n':
            NextLine();
            CRT::m_BeginChar = pTTy->t_outq.CurrentChar();
            m_Position = CRT::m_BeginChar;
            break;

        case 0x15:
            // del_line();
            break;

        case '\b':
            if (m_Position != CRT::m_BeginChar)
            {
                BackSpace();
                m_Position--;
            }
            break;

        case '\t':
            Tab();
            m_Position++;
            break;

        case TTy::KEY_LEFT:
            if (m_Position > m_BeginChar)
            {
                if (m_CursorX == 0) {
                    if (m_CursorY > 0) {
                        m_CursorY--;
                        m_CursorX = CRT::COLUMNS - 1;
                    }
                } else {
                    m_CursorX--;
                }
                MoveCursor(m_CursorX, m_CursorY);
                m_Position--;
            }
            break;

        case TTy::KEY_RIGHT:
            // Canon已经控制了RIGHT的边界，这里只需移动光标
            m_CursorX++;
            if (m_CursorX >= CRT::COLUMNS) {
                m_CursorX = 0;
                m_CursorY++;
                if (m_CursorY >= CRT::ROWS) {
                     m_CursorX = CRT::COLUMNS - 1; 
                     m_CursorY = CRT::ROWS - 1;
                }
            }
            MoveCursor(m_CursorX, m_CursorY);
            m_Position++;
            break;
        
        case TTy::KEY_UP:
        case TTy::KEY_DOWN:
            // UP/DOWN键不应该出现在输出队列中
            break;

        default:	/* 在屏幕上回显普��字笄1�7 */
            // 过滤掉特殊控制字符，避免显示乱码
            if ((unsigned char)ch >= 0x20 || ch == '\t')
            {
                WriteChar(ch);
                m_Position++;
            }
            break;
        }
    }
}

//======================================================================
// 移动硬件光标
//======================================================================
void CRT::MoveCursor(unsigned int col, unsigned int row)
{
    if ((col >= CRT::COLUMNS) || (row >= CRT::ROWS))
    {
        return;
    }

    /* 计算光标偏移釄1�71ￄ1�77 */
    unsigned short cursorPosition = row * CRT::COLUMNS + col;

    /* 选择寄存器，分别为光标位置的髄1�71ￄ1�778位和佄1�71ￄ1�778佄1�71ￄ1�77 */
    IOPort::OutByte(CRT::VIDEO_ADDR_PORT, 14);
    IOPort::OutByte(CRT::VIDEO_DATA_PORT, cursorPosition >> 8);
    IOPort::OutByte(CRT::VIDEO_ADDR_PORT, 15);
    IOPort::OutByte(CRT::VIDEO_DATA_PORT, cursorPosition & 0xFF);
}

//======================================================================
// 换行 + 屏幕滚动 + 缓冲区行号维抄1�71ￄ1�77
//======================================================================
void CRT::NextLine()
{
    m_CursorX = 0;
    ++m_CursorY;

    // 1. 缓冲区行号��增并清空新衄1�71ￄ1�77
    if (m_ScrollBuffer != 0)
    {
        ++m_CurrentLine;
        ++m_TotalLinesWritten;

        unsigned int newBufferLine = m_CurrentLine % BUFFER_LINES;
        unsigned int newBufferOffset = newBufferLine * COLUMNS;
        for (unsigned int col = 0; col < COLUMNS; ++col)
            m_ScrollBuffer[newBufferOffset + col] = ' ' | CRT::COLOR;
    }

    // 2. 屏幕滚动（仅在未查看历史时）
    if (m_CursorY >= ROWS)
    {
        if (m_ScrollBuffer != 0 && m_ScrollOffset == 0)
        {
            // 向上滚动屏幕内容
            for (unsigned int row = 0; row < ROWS - 1; ++row)
            {
                for (unsigned int col = 0; col < COLUMNS; ++col)
                {
                    m_VideoMemory[row * COLUMNS + col] =
                        m_VideoMemory[(row + 1) * COLUMNS + col];
                }
            }

            // 清空朢�后一衄1�71ￄ1�77
            for (unsigned int col = 0; col < COLUMNS; ++col)
                m_VideoMemory[(ROWS - 1) * COLUMNS + col] = ' ' | CRT::COLOR;
        }
        m_CursorY = ROWS - 1;
    }

    if (m_ScrollOffset == 0)
        MoveCursor(m_CursorX, m_CursorY);

    DrawScrollBar();
}

//======================================================================
// 逢�栄1�71ￄ1�77
//======================================================================
void CRT::BackSpace()
{
    m_CursorX--;

    /* 移动光标，如果要回到上一行的ￄ1�7 */
    if (m_CursorX >= (unsigned int)CRT::COLUMNS) // 由于ￄ1�7 unsigned，要防止下溢
    {
        m_CursorX = CRT::COLUMNS - 1;
        if (m_CursorY > 0)
        {
            --m_CursorY;
            if (m_ScrollBuffer != 0 && m_CurrentLine > 0)
            {
                --m_CurrentLine;
                --m_TotalLinesWritten;
            }
        }
        else
        {
            m_CursorY = 0;
        }
    }
    MoveCursor(m_CursorX, m_CursorY);

    /* 在光标所在位置填上空ￄ1�7 */
    m_VideoMemory[m_CursorY * COLUMNS + m_CursorX] = ' ' | CRT::COLOR;

    if (m_ScrollBuffer != 0)
    {
        unsigned int bufferLine = m_CurrentLine % BUFFER_LINES;
        unsigned int bufferOffset = bufferLine * COLUMNS + m_CursorX;
        m_ScrollBuffer[bufferOffset] = ' ' | CRT::COLOR;
    }
}

//======================================================================
// 制表笄1�71ￄ1�77
//======================================================================
void CRT::Tab()
{
    m_CursorX &= 0xFFFFFFF8;	/* 向左对齐到前丢�个Tab边界 */
    m_CursorX += 8;

    if (m_CursorX >= CRT::COLUMNS)
        NextLine();
    else
        MoveCursor(m_CursorX, m_CursorY);
}

//======================================================================
// 写字符：同时写入滚动缓冲区与当前屏幕
//======================================================================
void CRT::WriteChar(char ch)
{
    // 1. 优先写缓冲区（确保数据不丢失＄1�71ￄ1�77
    if (m_ScrollBuffer != 0)
    {
        unsigned int bufferLine = m_CurrentLine % BUFFER_LINES;
        unsigned int bufferOffset = bufferLine * COLUMNS + m_CursorX;
        m_ScrollBuffer[bufferOffset] = (unsigned char)ch | CRT::COLOR;
    }

    // 2. 只有在未滚动时才写屏幕（查看历史时不破坏显示＄1�71ￄ1�77
    if (m_ScrollOffset == 0)
    {
        m_VideoMemory[m_CursorY * COLUMNS + m_CursorX] =
            (unsigned char)ch | CRT::COLOR;
    }

    // 3. 更新光标
    ++m_CursorX;
    if (m_CursorX >= COLUMNS)
        NextLine();
    else if (m_ScrollOffset == 0)
        MoveCursor(m_CursorX, m_CursorY);
}

//======================================================================
// 清屏（只清当前屏幕，不动滚动缓冲区）
//======================================================================
void CRT::ClearScreen()
{
    unsigned int i;
    for (i = 0; i < COLUMNS * ROWS; ++i)
        m_VideoMemory[i] = (unsigned short)' ' | CRT::COLOR;

    m_CursorX = 0;
    m_CursorY = 0;
    MoveCursor(0, 0);
}

//======================================================================
// 初始化滚动缓冲区（在系统启动阶段调用＄1�71ￄ1�77
//======================================================================
void CRT::InitScrollBuffer()
{
    static unsigned short scrollBufferMemory[BUFFER_LINES * COLUMNS];
    m_ScrollBuffer = scrollBufferMemory;

    // 1. 初始化为空格+默认颜色
    for (unsigned int i = 0; i < BUFFER_LINES * COLUMNS; ++i)
        m_ScrollBuffer[i] = ' ' | CRT::COLOR;

    // 2. 保存当前屏幕内容（系统启动输出）
    for (unsigned int row = 0; row < ROWS; ++row)
    {
        for (unsigned int col = 0; col < COLUMNS; ++col)
        {
            m_ScrollBuffer[row * COLUMNS + col] =
                m_VideoMemory[row * COLUMNS + col];
        }
    }

    // 3. 書���光标位置初始化行�1�7
    m_CurrentLine = m_CursorY;
    m_TotalLinesWritten = m_CursorY + 1;
    m_ScrollOffset = 0;
    m_IsScrolling = false;

    DrawScrollBar();
}

//======================================================================
// 从缓冲区读一行到屏幕指定衄1�71ￄ1�77
//======================================================================
void CRT::ReadLineFromBuffer(unsigned int absLine, unsigned int screenRow)
{
    unsigned int physLine = absLine % BUFFER_LINES;
    unsigned int offset = physLine * COLUMNS;
    for (unsigned int col = 0; col < COLUMNS; ++col)
        m_VideoMemory[screenRow * COLUMNS + col] = m_ScrollBuffer[offset + col];
}

//======================================================================
// 刷新屏幕显示，根捄1�71ￄ1�77 m_ScrollOffset 选择窗口
//======================================================================
void CRT::RefreshScreen()
{
    if (m_ScrollBuffer == 0 || m_TotalLinesWritten == 0)
        return;

    // 1. 计算起始行号
    // startLine = (m_CurrentLine + 1) - ROWS - m_ScrollOffset
    unsigned int startLine;
    if (m_CurrentLine + 1 >= ROWS + m_ScrollOffset)
        startLine = (m_CurrentLine + 1) - ROWS - m_ScrollOffset;
    else
        startLine = 0;

    // 2. 从缓冲区读取并显礄1�71ￄ1�77
    for (unsigned int screenRow = 0; screenRow < ROWS; ++screenRow)
    {
        unsigned int bufferLine = startLine + screenRow;

        if (bufferLine > m_CurrentLine)
        {
            // 超出当前行，显示空行
            for (unsigned int col = 0; col < COLUMNS; ++col)
                m_VideoMemory[screenRow * COLUMNS + col] = ' ' | CRT::COLOR;
        }
        else
        {
            ReadLineFromBuffer(bufferLine, screenRow);
        }
    }

    // 3. 更新光标
    if (m_ScrollOffset == 0)
        MoveCursor(m_CursorX, m_CursorY);      // 朢�新位�
    else
        MoveCursor(COLUMNS - 1, ROWS - 1);     // 查看历史时，把光标放在右下角

    DrawScrollBar();
}

//======================================================================
// 上滚丢�行（PageUp＄1�71ￄ1�77
//======================================================================
void CRT::ScrollUp()
{
    if (m_ScrollBuffer == 0 || m_TotalLinesWritten <= ROWS)
        return;

    // 计算朢�大偏移量
    unsigned int maxOffset =
        (m_TotalLinesWritten < BUFFER_LINES)
        ? (m_TotalLinesWritten - ROWS)
        : (BUFFER_LINES - ROWS);

    if (m_ScrollOffset < maxOffset)
        ++m_ScrollOffset;

    m_IsScrolling = true;
    RefreshScreen();
}

//======================================================================
// 下滚丢�行（PageDown＄1�71ￄ1�77
//======================================================================
void CRT::ScrollDown()
{
    if (m_ScrollBuffer == 0 || m_ScrollOffset == 0)
        return;

    --m_ScrollOffset;
    if (m_ScrollOffset == 0)
        m_IsScrolling = false;

    RefreshScreen();
}
void CRT::GoToLatestLine()
{
    // 没有缓冲区直接返囄1�71ￄ1�77
    if (m_ScrollBuffer == 0)
        return;

    // 已经在最新位置就不用劄1�71ￄ1�77
    if (m_ScrollOffset == 0)
        return;

    // 逢�出历史模弄1�71ￄ1�77
    m_ScrollOffset = 0;
    m_IsScrolling = false;

    // �1�7 offset = 0 刷新屏幕，此�1�7 RefreshScreen 会显示最�1�7 ROWS �1�7
    // 并把光标移回 m_CursorX, m_CursorY（你之前的实现已经这样写了）
    RefreshScreen();
}

//======================================================================
// 绘制滚动�
//======================================================================
void CRT::DrawScrollBar()
{
    if (m_ScrollBuffer == 0) return;

    // 计算有效总行数（不超过缓冲区大小�
    unsigned int effectiveTotal = (m_TotalLinesWritten < BUFFER_LINES) ? m_TotalLinesWritten : BUFFER_LINES;
    
    // 默认滑块位置在最底部
    unsigned int thumbPos = ROWS - 1; 

    if (effectiveTotal > ROWS)
    {
        unsigned int maxOffset = effectiveTotal - ROWS;
        // 确保 offset 不越�
        unsigned int currentOffset = (m_ScrollOffset > maxOffset) ? maxOffset : m_ScrollOffset;
        
        // 计算滑块位置�
        // m_ScrollOffset = 0 (朢�底端) -> thumbPos = ROWS - 1
        // m_ScrollOffset = maxOffset (朢�顶端) -> thumbPos = 0
        // 使用 (ROWS - 1) 作为映射范围
        
        if (maxOffset > 0)
        {
            thumbPos = (ROWS - 1) - (currentOffset * (ROWS - 1) / maxOffset);
        }
    }

    // 绘制滚动�
    for (unsigned int i = 0; i < ROWS; ++i)
    {
        unsigned int offset = i * COLUMNS + (COLUMNS - 1); // 朢�后一�
        
        if (i == thumbPos)
        {
            // 滑块：白色实心方� (0xDB)
            m_VideoMemory[offset] = 0xDB | 0x0F00; 
        }
        else
        {
            // 轨道：灰色阴� (0xB0)，使用浅灰前�
            // 0x0700 � Light Grey on Black
            m_VideoMemory[offset] = 0xB0 | 0x0700; 
        }
    }
}
