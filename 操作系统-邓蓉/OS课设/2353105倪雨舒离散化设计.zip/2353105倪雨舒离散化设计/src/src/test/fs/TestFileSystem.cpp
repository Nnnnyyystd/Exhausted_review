#include "TestFileSystem.h"
#include "..\KernelInclude.h"
#include "..\TestUtility.h"

SuperBlock spb;

void PrintInode(char* InodeName, Inode* pInode)
{
	if ( NULL == pInode)
	{
		return;
	}
	Diagnose::Write("Inode INFO:  %s\n", InodeName);
	Diagnose::Write("Print Inode: dev = %d, No. [%d] On Block [%d], flag = %x, i_size = %d\n",pInode->i_dev, pInode->i_number % 8, FileSystem::INODE_ZONE_START_SECTOR + pInode->i_number / 8, pInode->i_flag, pInode->i_size);
	Diagnose::Write("addr = %x, number = %d, count = %d, nlink = %d, mode = %x\n", pInode, pInode->i_number, pInode->i_count, pInode->i_nlink, pInode->i_mode);
}

void LoadSuperBlock()
{
	User& u = Kernel::Instance().GetUser();
	BufferManager& bufMgr = Kernel::Instance().GetBufferManager();
	FileSystem& fileSys = Kernel::Instance().GetFileSystem();
	Buf* pBuf;

	for (int i = 0; i < 2; i++)
	{
		int* p = (int *)&spb + i * 128;

		pBuf = bufMgr.Bread(DeviceManager::ROOTDEV, FileSystem::SUPER_BLOCK_SECTOR_NUMBER + i);

		Utility::DWordCopy((int *)pBuf->b_addr, p, 128);

		bufMgr.Brelse(pBuf);
	}

	if (u.u_error)
	{
		Utility::Panic("Load SuperBlock Error....!\n");
	}

	fileSys.m_Mount[0].m_dev = DeviceManager::ROOTDEV;
	fileSys.m_Mount[0].m_spb = &spb;

	spb.s_flock = 0;
	spb.s_ilock = 0;
	spb.s_time = Time::time;

	return;
}

void MakeFS()
{
	/* ˵��:
	 * c.img�������򻮷֣�����������FileSystem���У������� 0 ~ 20,159 ��
	 * (0 - 99) (100, 101) (102 - 1023) (1024 - 20,159)
	 * (boot & kernel) (SuperBlock) (DiskInode Zone) (Data Zone)
	 */

	FileSystem& filesys = Kernel::Instance().GetFileSystem();
	
	/* initialize spb and mount[0] */
	filesys.m_Mount[0].m_dev = DeviceManager::ROOTDEV;
	filesys.m_Mount[0].m_spb = &spb;
	spb.s_flock = 0;
	spb.s_ilock = 0;
	spb.s_ronly = 0;
	spb.s_isize = FileSystem::INODE_ZONE_SIZE;
	spb.s_fsize = 20160;
	/* write some feature bytes of Superblock */
	spb.s_time = 0xAABBCCDD;
	spb.padding[46] = 0x473C2B1A;
	
	/* 
	 * ��������( 1024 <= blkno < 18000 )��ÿ��������Free(dev, blkno)һ�£�
	 * ���ɽ�����free block����"ջ��ջ"��ʽ��֯������
	 */
	for(int blkno = FileSystem::DATA_ZONE_END_SECTOR; blkno >= FileSystem::DATA_ZONE_START_SECTOR; --blkno)
	{
		filesys.Free(DeviceManager::ROOTDEV, blkno);
		//if(spb.s_nfree == 1) {Delay();Delay();}
	}

	/* Init spb.s_inode[]; */
	int total_inode = FileSystem::INODE_ZONE_SIZE * FileSystem::INODE_NUMBER_PER_SECTOR;
	
	spb.s_ninode = 0;
	for(int inode_num = total_inode - 1, count = 31; count > 0; --count )
	{
		spb.s_inode[spb.s_ninode++] = inode_num;
		inode_num--;
	}
	/* 0# DiskInode permanently for root dir */
	spb.s_inode[spb.s_ninode++] = 0;

	/****************** ��0# DiskInode��������Ŀ¼��DiskInode ******************/
    Inode* pNode = filesys.IAlloc(DeviceManager::ROOTDEV);

    User& u = Kernel::Instance().GetUser();
    pNode->i_flag |= (Inode::IACC | Inode::IUPD);
	pNode->i_mode = Inode::IALLOC | Inode::IFDIR /* Most vital!! */| Inode::IREAD | Inode::IWRITE | Inode::IEXEC | (Inode::IREAD >> 3) | (Inode::IWRITE >> 3) | (Inode::IEXEC >> 3) | (Inode::IREAD >> 6) | (Inode::IWRITE >> 6) | (Inode::IEXEC >> 6);
    pNode->i_nlink = 1;
    pNode->i_uid = u.u_uid;
    pNode->i_gid = u.u_gid;

    g_InodeTable.IPut(pNode);	/* ��rootDir DiskInodeд����� */
	/****************** ��0# DiskInode��������Ŀ¼��DiskInode ******************/
	
	/* ��SuperBlockд��c.img��ȥ */
	spb.s_fmod = 1;
	filesys.Update();
	
	return;
}

void InitTTyInode()
{
	User& u = Kernel::Instance().GetUser();
	FileManager& fileMgr = Kernel::Instance().GetFileManager();
	Inode* pInode;
	
	u.u_dirp = "/tty1";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	if (u.u_error != User::NOERROR)
	{
		Diagnose::Write("user error = %d \n", u.u_error);
		while(true);
	}
	/* tty1�����Ͳ����ڣ�NameI��Ȼ����NULL������MakNode����tty1 */
	if ( NULL == pInode )
	{
		pInode = fileMgr.MakNode(0x1FF);	/* rwxrwxrwx */
		if(NULL == pInode)
		{
			Diagnose::Write("Create /tty1 failed!\n");
			while(true);
		}
		else
		{
			/* Modify tty1's Inode attribute */
			pInode->i_flag |= (Inode::IACC | Inode::IUPD);
			pInode->i_mode = Inode::IALLOC | Inode::IFCHR /* Most vital!! */| Inode::IREAD | Inode::IWRITE | Inode::IEXEC | (Inode::IREAD >> 3) | (Inode::IWRITE >> 3) | (Inode::IEXEC >> 3) | (Inode::IREAD >> 6) | (Inode::IWRITE >> 6) | (Inode::IEXEC >> 6);
			pInode->i_addr[0] = DeviceManager::TTYDEV;

			PrintInode("rootDir", u.u_pdir);
			/* Print tty1 Inode */
			PrintInode("tty1", pInode);

			pInode->Prele(); /* IPut(pInode)Ч����ͬ */

			Diagnose::Write("Create /file1 succeed! \n");
		}
	}/* ���ˣ�����tty1�ɹ�! */

	Kernel::Instance().GetFileSystem().Update();
}

/* �����MakeFS()������̣�������������superblockд��c.img����Ϊ����Ŀ�ġ� */
bool AllocAllBlock()
{
	FileSystem& filesys = Kernel::Instance().GetFileSystem();
	BufferManager& bufMgr = Kernel::Instance().GetBufferManager();

	Buf* pBuf;
	/* Empty all the free block */
	for(int i = 0; i < FileSystem::DATA_ZONE_SIZE; i++)
	{
		pBuf = filesys.Alloc(DeviceManager::ROOTDEV);
		Diagnose::Write("blkno Allocated = %d\n", pBuf->b_blkno);
		
		/* 
		 * ����Alloc()�����GetBlk()�������Brelse()��
		 * ��ܿ콫NBUF��Buf�ľ�... :(
		 */
		bufMgr.Brelse(pBuf);

		if( i + FileSystem::DATA_ZONE_START_SECTOR != pBuf->b_blkno)
		{
			/* ���䵽���ַ����(or������)Ӧ����1024, 1025, 1026, ... , 20,159������ */
			Diagnose::Write("Test Failed in AllocAllBlock()!\n");
			while(1);
			return false;
		}
	}
	return true;
}


bool IAllocTest()
{
	Inode* pNode;
	FileSystem& filesys = Kernel::Instance().GetFileSystem();

	/* IAlloc()ִ��10�Σ�������ǰ��ʼ��spbֱ�ӹ�����DiskInode����count����
	 * IAlloc()�������ռ���100��Inode�����Ҳ��Ὣ��IAlloc()��ȥ��0# DiskInode
	 * �ռ�������
	 */
	for( int i = 0; i < 10; i++ )
	{
		if( pNode = filesys.IAlloc(DeviceManager::ROOTDEV))
		{
			Diagnose::Write("Inode [%d] allocated.. No.[%d] on Block [%d] !\n", pNode->i_number, pNode->i_number % 8, FileSystem::INODE_ZONE_START_SECTOR + pNode->i_number / 8 );
			Diagnose::Write("Inode.count = %d, Inode.nlink = %d, i_dev = %d, i_number = %d\n", pNode->i_count, pNode->i_nlink, pNode->i_dev, pNode->i_number);
		}
		Delay();
	}
	
	/* ����һ��������Կ����ѷ����ȥ��0# Inodeȷʵû�б�IAlloc()��spb.s_Inode[] */
	Diagnose::Write("spb.s_Inode[0] = %d, spb.s_Inode[%d] = [%d]\n", spb.s_inode[0], spb.s_ninode-1, spb.s_inode[spb.s_ninode-1]);
	Delay();
	
	filesys.Update();
	return true;
}

bool NameIandMakNodeTest()
{
	User& u = Kernel::Instance().GetUser();
	FileManager& fileMgr = Kernel::Instance().GetFileManager();
	Inode* pInode;
	int parentDirSize = 0;

	/* u.u_dirpָ��Ҫ������·��char* pathname������open(),creat()ϵͳ����
	 * u.u_dirpֵ��SystemCall::Trap()�г�ʼ��������дTest case��Ҫ�ֹ����У�
	 * ��CREATE��ʽ����NameI()��
	 */

	//Case 1: Open non-exist file --> Create non-exist file --> Open exist file
	char* filePath1 = "/testfile1";	
	u.u_dirp = filePath1;
	u.u_error = User::NOERROR;
	/* ���Ҳ����ڵ�/testfile1��NameI()����NULL */
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::OPEN);
	PrintResult(
		"NameITest 1-1",
		User::ENOENT == u.u_error && NULL == pInode
		);
	
	u.u_dirp = filePath1;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	PrintResult(
		"NameITest 1-2",
		User::NOERROR == u.u_error && NULL == pInode
		);
	/* MakNode()��������/testfile1��Inode,�����Ժ�NameI()�н��޷�IGet()��Inode! */
	parentDirSize = u.u_pdir->i_size;
	pInode = fileMgr.MakNode(Inode::IRWXU | Inode::IRWXG | Inode::IRWXO);	/* rwxrwxrwx */
	PrintResult(
		"NameITest 1-3",
		User::NOERROR == u.u_error && NULL != pInode
		&& u.u_pdir->i_size == parentDirSize + (int)sizeof(DirectoryEntry)
		);
	pInode->Prele();

	u.u_dirp = filePath1;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::OPEN);
	PrintResult(
		"NameITest 1-4",
		User::NOERROR == u.u_error && NULL != pInode
		&& 0 == pInode->i_size		/* Empty file */
		);
	pInode->Prele();
	
	u.u_dirp = filePath1;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::DELETE);
	PrintResult(
		"NameITest 1-5",
		User::NOERROR == u.u_error && pInode == u.u_pdir
		);
	pInode->Prele();


	//Case 2: Open non-exist file in non-exist folder --> Create non-exist file in non-exist folder
	/* NameI()�޷�һ���Խ�����Ŀ¼��ε��ļ���ֻ�ܶ�ε�����㽨��Ŀ¼�ṹ����󴴽��ļ� */
	char* filePath2 = "/nonexist/testfile2";
	u.u_dirp = filePath2;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::OPEN);
	PrintResult(
		"NameITest 2-1", 
		User::ENOENT == u.u_error && NULL == pInode
		);

	u.u_dirp = filePath2;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	PrintResult(
		"NameITest 2-2",
		User::ENOENT == u.u_error && NULL == pInode
		);


	//Case 3:  Delete non-exist file
	char* filePath3 = "/testfile3";
	u.u_dirp = filePath3;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::DELETE);
	PrintResult(
		"NameITest 3-1",
		User::ENOENT == u.u_error && NULL == pInode
		);


	//Case 4: Create new folder --> Create new file in the new folder
	char* filePath4 = "/testfolder/testfile4";
	u.u_dirp = filePath4;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	PrintResult(
		"NameITest 4-1",
		User::ENOENT == u.u_error && NULL == pInode
		);
	u.u_error = User::NOERROR;
	parentDirSize = u.u_pdir->i_size;
	pInode = fileMgr.MakNode(Inode::IFDIR/* Vital */ | Inode::IRWXU | Inode::IRWXG | Inode::IRWXO);	/* rwxrwxrwx */
	PrintResult(
		"NameITest 4-2",
		User::NOERROR == u.u_error && NULL != pInode
		&& u.u_pdir->i_size == parentDirSize + (int)sizeof(DirectoryEntry)
		);
	pInode->Prele();

	u.u_dirp =filePath4;
	u.u_error = User::NOERROR;
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	PrintResult(
		"NameITest 4-3",
		User::NOERROR == u.u_error && NULL == pInode
		&& 0 == u.u_pdir->i_size	/* new created folder */
		);
	parentDirSize = u.u_pdir->i_size;
	pInode = fileMgr.MakNode(Inode::IRWXU | Inode::IRWXG | Inode::IRWXO);
	PrintResult(
		"NameItest 4-4",
		User::NOERROR == u.u_error && NULL != pInode
		&& u.u_pdir->i_size == parentDirSize + (int)sizeof(DirectoryEntry)
		);
	pInode->Prele();

	/* ���ڴ�Inode���޸�д��c.img */
	fileMgr.m_FileSystem->Update();
	/* MakNode()->WriteDir()->WriteI()�а�δ��512�ֽڵ��̿���"�ӳ�д"��
	 * ����������Ҫ���ӳ��̿�д��c.img��ע����ROOTDEV����Update()����NODEV��
	 */
	Kernel::Instance().GetBufferManager().Bflush(DeviceManager::ROOTDEV);
	return true;
}

bool NameITest()
{
	User& u = Kernel::Instance().GetUser();
	FileManager& fileMgr = Kernel::Instance().GetFileManager();
	Inode* pInode;

	/* Ҫ������pathname����create��ʽ����NameI() */
	u.u_dirp = "/file1";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	if (u.u_error != User::NOERROR)
	{
		Diagnose::Write("user error = %d \n", u.u_error);
		while(true);
	}
	/* file1�����Ͳ����ڣ�NameI��Ȼ����NULL������MakNode����file1 */
	if ( NULL == pInode )
	{
		pInode = fileMgr.MakNode(0x1FF);
		if(NULL == pInode)
		{
			Diagnose::Write("Create /file1 failed!\n");
			while(true);
		}
		else
		{
			PrintInode("rootDir", u.u_pdir);
			/* Print file1 Inode */
			PrintInode("pInode", pInode);

			/* ����Unlock file1 Inode!!! �����Ժ�NameI()�н��޷�IGet() file1 Inode */
			pInode->Prele(); /* IPut(pInode)Ч����ͬ */

			Diagnose::Write("Create /file1 succeed! \n");
		}
	}/* ���ˣ�����file1�ɹ�! */

	/* Ҫ������·�� */
	u.u_dirp = "/fileX";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::OPEN);
	/* Obviously it will fail! */
	if ( NULL == pInode )
	{
		Diagnose::Write("/fileX: NameI() failed !\n");
	}
	else
	{
		Diagnose::Write("/fileX: NameI() OK !\n");
		while(true);
	}

	/* u_errorһ��Ҫ���㣬����ǰһ��NameI()��ʧ�ܻᵼ������file1Ҳʧ�� */
	u.u_error = User::NOERROR;
	u.u_dirp = "/file1";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::OPEN);
	if ( NULL == pInode )
	{
		Diagnose::Write("/file1: NameI() failed !\n");
		while(true);
	}
	else
	{
		pInode->Prele();	/* Unlock Inode */
		Diagnose::Write("/file1: NameI() OK !\n");
		PrintInode("file1", pInode);
	}

	/* Disable Output!!! */
	Diagnose::TraceOff();

	/* ���ڴ�Inode���޸�д��c.img */
	fileMgr.m_FileSystem->Update();
	/* MakNode()->WriteDir()->WriteI()�а�δ��512�ֽڵ��̿���"�ӳ�д"������������Ҫ���ӳ��̿�д��c.img */
	Kernel::Instance().GetBufferManager().Bflush(DeviceManager::ROOTDEV);

	Diagnose::TraceOn();
	return true;
}

bool SetupDirTree()
{
	User& u = Kernel::Instance().GetUser();
	FileManager& fileMgr = Kernel::Instance().GetFileManager();
	Inode* pInode;

	u.u_dirp = "/Folder";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	if (u.u_error != User::NOERROR)
	{
		Diagnose::Write("user error = %d \n", u.u_error);
		while(true);
	}

	if ( NULL == pInode )
	{
		pInode = fileMgr.MakNode(Inode::IFDIR | 0x1FF);
		if ( NULL == pInode )
		{
			Diagnose::Write("Create /New Folder failed!\n");
			while(true);
		}
		else
		{
			PrintInode("Parent Inode", u.u_pdir);
			PrintInode("/New Folder", pInode);
			pInode->Prele();
			Diagnose::Write("Create /New Folder succeed! \n");
		}
	}

	u.u_dirp = "/Folder/SubFolder";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	if ( NULL == pInode )
	{
		pInode = fileMgr.MakNode(Inode::IFDIR | 0x1FF);
		if ( NULL == pInode )
		{
			Diagnose::Write("Create /Sub Folder failed!\n");
			while(true);
		}
		else
		{
			pInode->Prele();
			Diagnose::Write("Create /Sub Folder succeed! \n");
		}
	}

	u.u_dirp = "/bin";
	pInode = fileMgr.NameI(FileManager::NextChar, FileManager::CREATE);
	if (u.u_error != User::NOERROR)
	{
		Diagnose::Write("User error = %d \n", u.u_error);
		while(true);
	}
	if ( NULL == pInode )	/* /bin not exist, pInode should be NULL!! */
	{
		pInode = fileMgr.MakNode(0x1FF);
		if(NULL == pInode)
		{
			Diagnose::Write("Create /bin failed!\n");
			while(true);
		}
		else
		{
			pInode->i_flag |= (Inode::IACC | Inode::IUPD);
			pInode->i_mode = Inode::IALLOC | Inode::IFDIR /* Most vital!! */| Inode::IREAD | Inode::IWRITE | Inode::IEXEC | (Inode::IREAD >> 3) | (Inode::IWRITE >> 3) | (Inode::IEXEC >> 3) | (Inode::IREAD >> 6) | (Inode::IWRITE >> 6) | (Inode::IEXEC >> 6);

			Diagnose::TraceOn();
			PrintInode("/", u.u_pdir);
			PrintInode("/bin", pInode);
			//Delay();Delay();
			pInode->Prele();
			Diagnose::Write("Create /bin succeed! \n");
		}
	}

	//Diagnose::TraceOff();
	fileMgr.m_FileSystem->Update();
	Kernel::Instance().GetBufferManager().Bflush(DeviceManager::ROOTDEV);
	//Diagnose::TraceOn();

	return true;
}

bool TestFileSystem()
{
	if ( true == NameITest() )
	{
		return true;
	}
	else
	{
		return false;
	}
	// MakeFS();

	// /* Related Functions as IFree(), IGet(), IPut(), 
	 // * IUpdate()... Successfully Tested ^_^
	 // */
	// IAllocTest();

	// if(AllocAllBlock() == true)
	// {
		// Diagnose::Write("Test in AllocAllBlock() Succeed!\n");
		// return true;
	// }
	// return false;
}

